import type { Metadata } from "next";
import PageHead from "@/components/PageHead";
import { site } from "@/lib/data";

export const metadata: Metadata = { title: "Contact", description: "Contact Anaswara KC about digital marketing roles and collaborations." };

export default function Contact() {
  const rows = [
    { label: "Email", value: site.email, href: `mailto:${site.email}` },
    { label: "Phone", value: site.phone, href: `tel:${site.phone.replace(/\s/g, "")}` },
    { label: "LinkedIn", value: "linkedin.com/in/anaswara-kc", href: site.linkedin },
    { label: "Website", value: "anaswarakc.com", href: site.website },
  ];
  return (
    <>
      <PageHead tint="bg-lilac" title="Hiring for digital marketing? Let's talk." intro="I am open to conversations about SEO, paid ads and social media roles, and to collaborations." />
      <div className="mx-auto max-w-3xl px-5 pt-14">
        <ul className="divide-y-2 divide-ink/10 rounded-3xl border-2 border-ink bg-white">
          {rows.map((r) => (
            <li key={r.label} className="flex flex-col gap-1 p-5 sm:flex-row sm:items-center sm:justify-between">
              <span className="font-semibold">{r.label}</span>
              <a href={r.href} className="text-purple underline underline-offset-4" {...(r.href.startsWith("http") ? { target: "_blank", rel: "noopener noreferrer" } : {})}>{r.value}</a>
            </li>
          ))}
        </ul>
        <div className="mt-8 flex flex-wrap gap-3">
          <a href={`mailto:${site.email}?subject=Digital%20marketing%20opportunity`} className="btn btn-pink">Email me</a>
          <a href={site.resume} download className="btn btn-ink">Download resume</a>
        </div>
      </div>
    </>
  );
}
