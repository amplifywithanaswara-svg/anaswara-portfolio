import type { Metadata } from "next";
import PageHead from "@/components/PageHead";
import { education, certifications, awards } from "@/lib/data";

export const metadata: Metadata = { title: "About", description: "Education, training and career journey of Anaswara KC, digital marketing executive in Kannur." };

type Item = { name: string; org?: string; date?: string };
const List = ({ title, items, bg }: { title: string; bg: string; items: Item[] }) => (
  <section className={`rounded-3xl p-6 ${bg}`}>
    <h2 className="text-xl font-bold">{title}</h2>
    <ul className="mt-4 space-y-3">
      {items.map((i) => (
        <li key={i.name}><p className="font-semibold">{i.name}</p>
          <p className="text-sm text-ink/75">{[i.org, i.date].filter(Boolean).join(", ")}</p></li>
      ))}
    </ul>
  </section>
);

export default function About() {
  return (
    <>
      <PageHead title="From document processing to digital marketing" intro="How I got here, and what I am focused on now." />
      <div className="mx-auto grid max-w-6xl gap-12 px-5 pt-14 lg:grid-cols-5">
        <div className="max-w-prose space-y-5 text-lg leading-relaxed lg:col-span-3">
          <p>I studied Commerce (BCom Cooperation) at Kannur University from 2021 to 2024, then worked as a document processor at CCAN Solutions, where accuracy and deadlines were the job.</p>
          <p>In 2025 I moved into digital marketing. I completed four months of training at Opentutor Digital Academy in Kannur, worked there as an intern, and finished with three awards: Best Student, Social Media Excellence and SEO Topspot.</p>
          <p>Since March 2026 I have been at PVA Ayurvedic Hospital in Kannur, where I handle SEO, Meta Ads, Google Ads, social media and campaign reporting. My own website also ranks on the first page of Google for multiple keywords.</p>
          <p>I want to keep building depth in SEO, paid advertising and lead generation, and I work in Malayalam and English.</p>
          <p className="text-base text-ink/70">Working style: communication, adaptability, teamwork, time management and problem solving.</p>
        </div>
        <div className="space-y-5 lg:col-span-2">
          <List title="Education" bg="bg-lilac" items={education} />
          <List title="Certifications" bg="bg-peach" items={certifications} />
          <List title="Awards" bg="bg-blush" items={awards} />
        </div>
      </div>
    </>
  );
}
