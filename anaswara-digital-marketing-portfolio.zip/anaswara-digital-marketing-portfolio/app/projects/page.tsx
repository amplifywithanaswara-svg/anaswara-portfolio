import type { Metadata } from "next";
import PageHead from "@/components/PageHead";
import ProjectCard from "@/components/ProjectCard";
import { projects } from "@/lib/data";

export const metadata: Metadata = { title: "Projects", description: "Professional, training and personal digital marketing projects by Anaswara KC." };

export default function Projects() {
  return (
    <>
      <PageHead tint="bg-peach" title="Projects and case studies" intro="Each card is labelled Professional, Training or Personal. Result and screenshot slots are placeholders until verified numbers and images are added." />
      <div className="mx-auto grid max-w-6xl gap-6 px-5 pt-14 md:grid-cols-2 lg:grid-cols-3">
        {projects.map((p) => <ProjectCard key={p.title} p={p} />)}
      </div>
    </>
  );
}
