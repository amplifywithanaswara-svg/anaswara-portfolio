import type { Metadata } from "next";
import PageHead from "@/components/PageHead";
import { experience } from "@/lib/data";

export const metadata: Metadata = { title: "Experience", description: "Work experience of Anaswara KC: PVA Ayurvedic Hospital, Opentutor Digital Academy and CCAN Solutions." };

export default function Experience() {
  return (
    <>
      <PageHead title="Experience" intro="Most recent first." />
      <div className="mx-auto max-w-3xl px-5 pt-14">
        <ol className="space-y-10 border-l-4 border-pink">
          {experience.map((e) => (
            <li key={e.company} className="relative pl-8">
              <span className="absolute -left-[0.6rem] top-2 h-4 w-4 rounded-full border-4 border-pink bg-cream" aria-hidden="true" />
              <p className="text-sm font-semibold text-purple">{e.period} <span className="text-ink/50">({e.kind})</span></p>
              <h2 className="mt-1 text-2xl font-bold">{e.role}</h2>
              <p className="text-ink/75">{e.company}</p>
              <ul className="mt-3 list-disc space-y-1 pl-5">{e.points.map((p) => <li key={p}>{p}</li>)}</ul>
            </li>
          ))}
        </ol>
      </div>
    </>
  );
}
